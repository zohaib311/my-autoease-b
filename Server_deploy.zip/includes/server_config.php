<?php
return [
    'APP_ENV' => 'production',
    'APP_URL' => 'https://autoease.unaux.com',

    'API_URL' => 'http://localhost:3000',
    'CORS_ALLOWED_ORIGINS' => 'https://your-frontend-domain.com,http://localhost:3000',
    'FRONTEND_URL' => 'http://localhost:3000',

    'DB_HOST' => 'sql100.ezyro.com',
    'DB_NAME' => 'ezyro_41775189_autoease',
    'DB_USER' => 'ezyro_41775189',
    'DB_PASS' => 'e4cdf1107396',
    'DB_PORT' => '3306',

    'STRIPE_SECRET_KEY' => 'sk_test_or_live_your_key',
];
